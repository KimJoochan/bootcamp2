/*마크 추가*/
function addMarker(lat, lon, name) {
    var location = {
        lat: parseFloat(lat),
        lng: parseFloat(lon)
    };
    var marker = new google.maps.Marker({
        position: location,
        map: map
    });
    var marker2 = new google.maps.Marker({
        position: location,
        map: map2
    });
    var infowindow = new google.maps.InfoWindow({
        content: name
    });
    marker.addListener('click', function () {
        infowindow.open(map, marker);
    })
    marker2.addListener('click', function () {
        infowindow.open(map2, marker2);
    })
}
let js;
$(document).ready(function () {
    /*json시작으로 파싱하여 갖추기*/
    $("#allTop").click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 500)
    })
    $.session.set("login", "false");
    $.session.set("id", "null");
    $.getJSON('text.json', function (data) {
        for (var item in data) {
            $('#pla').append(`<a class="item ${item}">${data[item]['subTitle']}</a>`);
            $('#place').append(`<option value="${data[item]['subTitle']}">${data[item]['subTitle']}</option>`)
            $('#boardSel').append(`<a class="item" id="${item}">${data[item]['subTitle']}</a>`);
            addMarker(data[item]['lat'], data[item]['lon'], data[item]['subTitle']);
        }
        $('#pla>a').click(function () {
            let keys = $(this).attr('class');
            let point = keys.split(' ')[1];
            for (var j in data) {
                if (j == point) {
                    var latLng = new google.maps.LatLng(parseFloat(data[j]['lat']), parseFloat(data[j]['lon']));
                    map.panTo(latLng);
                }
            }
        });
        $('#boardSel>a').click(function () {
             $('#boardSel>a').removeClass('active');
            $(this).addClass('active');
            let key = $(this).attr('id');
            $.getJSON('board.json', function (datas) {
                $('#board').find('tbody').html("");
                for (var ite of datas[key]) {
                    $('#board').find('tbody').append(`<tr>
                        <td>${ite['name']}</td>
                        <td>${ite['Email']}</td>
                        <td>${ite['title']}</td>
                        <td>${ite['date']}</td>
                    </tr>`)
                }
            })
        })
    });

    $('#but').dropdown();
    var swiper = new Swiper('.swiper-container', {
        pagination: {
            el: '.swiper-pagination',
            dynamicBullets: true,
        },
    });
    /*로그인 버튼클릭시 등작*/
    var checked = "";
    var checked2 = "예약대기";
    $('#log').click(function () {
        $('#login').modal({
            closable: false,
            onApprove: function () {
                $.ajax({
                    url: "php/login.php",
                    type: "post",
                    data: $('#login>.login').serialize(),
                    success: function (data) {
                        console.log(data)
                        //js = JSON.parse(data);/*
                        if (js['state'] == "1") {
                            alert('로그인!');
                            $.session.set("login", "true");
                            $.session.set("id", js['id']);
                            $('#log').hide();
                            $('#joi').hide();
                            $('#dropM .menu').append(`<div class="item" id="logout">Logout</div>`);
                            $('#dropM .menu').append(`<div class="item" id="mypage">Mypage</div>`);*/
                    //        마이페이지 추가
                            $.ajax({
                                url: 'php/mypage.php',
                                data: `id=${js['id']}`,
                                type: "GET",
                                success: function (data) {
                                    $('#myTable>tbody').html("");
                                    var item = JSON.parse(data);
                                    for (var i in item['pla']) {
                                        if (item["pla"][i] != "") {
                                            console.log(item["check"][i])
                                            if (item["check"][i] == "1") {
                                                checked = "active";
                                                checked2 = "예약완료";
                                            } else {
                                                checked = "";
                                                checked2 = "예약대기";
                                            }
                                            $('#myTable>tbody').append(` <tr class="${checked}">
                    <td>${item["pla"][i]}</td>
                    <td>${item["chDa"][i]}</td>
                    <td>${item["chT"][i]}</td>
                    <td>${checked2}</td>
                </tr>`)
                                        }
                                    }
                                }
                            })
                            $('#mypage').click(function () {
                                $('#myp').modal('show');
                            })
                            $('#logout').click(function () {
                                $.session.set("login", "false");
                                $('#log').show();
                                $('#joi').show();
                                $(this).hide();
                            });
                            $('#reserve>.reser').append(`<input type="hidden" value="${js['id']}" name="id">`);
                        } else {
                            alert('로그인실패-_-');
                        }
                        $('#login input').val("");
                    }
                })
            }
        }).modal('show');
    });
    /*회원가입 버튼클릭시 등작*/
    $('#joi').click(function () {
        $('#join').modal({
            closable: false,
            onApprove: function () {
                $.ajax({
                    url: "php/join.php",
                    type: "post",
                    data: $('#join>.join').serialize(),
                    success: function (data) {
                        if (data == 1) {
                            alert('회원가입성공!');
                        } else {
                            alert('회원가입실패-_-');
                            return false;
                        }
                        $('#join input').val("");
                    }
                })
            }
        }).modal('show')
    });
    /*예약하기 버튼클릭시 등작*/
    $('#resve').click(function () {
        if ($.session.get("login") == "true") {
            $('#reserve').modal({
                closable: false,
                onApprove: function () {
                    $.ajax({
                        url: "php/reserve.php",
                        type: "post",
                        data: $('#reserve>.reser').serialize(),
                        success: function (data) {
                            if (data == "0") {
                                alert("예약실패");
                            } else {
                                alert("메세지 전달");
                            }
                            $('#reserve>.reser').val("");
                        }
                    });
                    $.ajax({
                        url: 'php/mypage.php',
                        data: `id=${js['id']}`,
                        type: "GET",
                        success: function (data) {
                            $('#myTable>tbody').html("");
                            var item = JSON.parse(data);
                            for (var i in item['pla']) {
                                if (item["pla"][i] != "") {
                                    if (item["check"][i] == "1") {
                                        checked = "active";
                                        checked2 = "예약완료";
                                    } else {
                                        checked = "";
                                        checked2 = "예약대기";
                                    }
                                    $('#myTable>tbody').append(` <tr class="${checked}">
                    <td>${item["pla"][i]}</td>
                    <td>${item["chDa"][i]}</td>
                    <td>${item["chT"][i]}</td>
                    <td>${checked2}</td>
                </tr>`)
                                }
                            }
                        }
                    });
                }
            }).modal('show')
        } else {
            alert('로그인 후 사용 가능')
        }
    });
    $('#checkDate').datepicker({
        dateFormat: 'yy-mm-dd'
    });
    $('#checkTime').timepicker({
        scrollDefault: 'now'
    });
    /*이벤트 배너 넘기기*/
    let eWidth = $('#evWrap').width() / 3;
    let count = 0;
    $('.pos.left').click(function () {
        count++;
        if (count > 0 && count < 3) {
            $('#evWrap').animate({
                left: eWidth * -1 * count
            })
        } else if (count > 2) {
            $('#evWrap').animate({
                left: 0
            });
            count = 0;
        }
    });
    $('.pos.right').click(function () {
        count--;
        if (count >= 0 && count < 2) {
            $('#evWrap').animate({
                left: eWidth * -1 * count
            })
        } else if (count < 0) {
            count = 2;
            $('#evWrap').animate({
                left: eWidth * -1 * count
            });
        }
    })
    /*홍보물 화면 전환*/
    $('.shape').click(function () {
        $(this).shape('flip right');
    })


    /*지도로 보기*/
    $('#lookMap').click(function () {
        $('#modMap').modal('show')
    });
    $('.hyper').click(function () {
        let key = $(this).attr('id');
        $.getJSON('text.json', function (data) {
            let load = data[key];
            $('#text_title').html(load['title']);
            $('#text_sub').html(load['subTitle']);
            $('#text_sentence').html(load['sentence']);
            $('#text').modal('show');
        })
    })
    /*게시글 작성 폼*/
    $('#write').click(function () {
        $('#writeForm').modal({
            centered: false
        }).modal('show');
    });
})

 function chat(form) {
     let name = form.name.value;
     let speak = form.msg.value;
     let data = `msg=${speak}&name=${name}`;
     var xhr = new XMLHttpRequest();
     xhr.open('GET', './php/chat.php?' + data);
     xhr.onreadystatechange = function () {
         if (xhr.readyState === 4 && xhr.status === 200) {
             console.log(xhr.responseText);
         }
     }
     xhr.send();
 }
 $(document).ready(function () {
     setInterval(function () {
         console.log(123)
         $('#chat').text("");
         $.getJSON("php/chatroad.php", function (data) {
             console.log(data);
             for (var i in data['name']) {
                 if (data['name'] != "") {
                     $('#chat').append(`
    <div class="comment">
            <a class="avatar">
                <img src="img/man.png">
            </a>
            <div class="content">
                <a class="author">${data['name'][i]}</a>
                <div class="metadata">
                    <span class="date">${data['time'][i]}</span>
                </div>
                <div class="text">
                    <p>${data['msg'][i]}</p>
                </div>
                <div class="actions">
                    <a class="reply">Reply</a>
                </div>
            </div>
        </div>
`)
                 }
             }

         })
     }, 1000)
 })

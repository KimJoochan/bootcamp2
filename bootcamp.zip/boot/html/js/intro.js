$(document).ready(function () {
    $('#home').click(function () {
        location.href="home.html"
    })
    $('#chat').click(function () {
        $('body').html("");
        $('body').load("comment.html");
    })
    $('#goog').click(function () {
        alert('준비중입니다.');
    });
    $('#ad').click(function () {
        alert('준비중입니다.');
    });
})

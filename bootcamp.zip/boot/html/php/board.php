<?php
    echo($_GET['key']);
?>
<?php 
    include('db.php');
    date_default_timezone_set("Asia/Seoul");
    $nw=date("Y/m/d")."-".date("h:i:sa");
    $name=$_GET['name'];
    $msg=$_GET['msg'];
    $sql="insert into chat values('$nw','$name','$msg')";
    mysqli_query($conn,$sql);
?>
<?php 
    include('db.php');
    $sql="select * from chat";
    $rs=mysqli_query($conn,$sql);
    $name_array=array("");
    $msg_array=array("");
    $time_array=array("");
    while($arr=mysqli_fetch_array($rs)){
      array_push($name_array,$arr['name']);
      array_push($msg_array,$arr['msg']);
      array_push($time_array,$arr['sendtime']);
    }
$myObj=array('name'=>$name_array,'msg'=>$msg_array,'time'=>$time_array);
    echo json_encode($myObj);
?>
<!--msg: (3) ["", "123123", "321321"]
name: (3) ["", "회사명", "김주찬"]
time: (3) ["", "2019/11/28-10:09:17pm", "2019/11/28-10:13:22pm"]
__proto__: Object
-->

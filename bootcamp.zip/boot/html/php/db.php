<?php
    header('Content-Type: text/html; charset=utf-8');
    $conn=mysqli_connect("localhost", "root", "", "boot");
    mysqli_query($conn, "set session character_set_connection=utf8;");
    mysqli_query($conn, "set session character_set_results=utf8;");
    mysqli_query($conn, "set session character_set_client=utf8;");
?>

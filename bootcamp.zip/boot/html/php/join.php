<?php
    include('db.php');
    $name=$_POST['name'];
    $id=$_POST['id'];
    $pwd=$_POST['pwd'];
    $phone=$_POST['phone'];
    $sex=$_POST['sex'];
    $num=$_POST['num'];
    if($name=="" || $id=="" || $pwd=="" || $phone=="" || $sex=="" || $num==""){
        echo 0;
    }else{
        $sql="insert into member values('$name','$id','$pwd','$phone','$sex','$num')";
        $rs=mysqli_query($conn,$sql);
        echo $rs;
    }
?>

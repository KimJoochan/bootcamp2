<?php
    include('db.php');
    $id=$_POST['id'];
    $pwd=$_POST['pwd'];
    $sql="select * from member where id='$id'and pwd='$pwd'";
    $rs=mysqli_query($conn,$sql);
    $result=0;
    $myObj;
    while($arr=mysqli_fetch_array($rs)){
        if($id==$arr['id']){
$myObj=array('name'=>$arr['name'],'id'=>$arr['id'],'phone'=>$arr['phone'],'state'=>'1');
            break;
        }
    }
  echo json_encode($myObj);
?>

<?php 
    include('db.php');
    $id=$_GET['id'];
    $sql="select * from reserve where putid='$id'";
    $rs=mysqli_query($conn,$sql);
    $pla_array=array("");
    $chDa_array=array("");
    $chTi_array=array("");
    $check_array=array("");
    while($arr=mysqli_fetch_array($rs)){
      array_push($pla_array,$arr['place']);
      array_push($chDa_array,$arr['chDate']);
      array_push($chTi_array,$arr['chTime']);
      array_push($check_array,$arr['checked']);
    }
$myObj=array('pla'=>$pla_array,'chDa'=>$chDa_array,'chT'=>$chTi_array,'check'=>$check_array);
    echo json_encode($myObj);
?>
<?php
/**/
    include('db.php');
    $place=$_POST['place'];
    $chDate=$_POST['chDate'];
    $chTime=$_POST['chTime'];
    $during=$_POST['during'];
    $many=$_POST['many'];
    $id=$_POST['id'];
 if($place=="" || $chDate=="" || $chTime=="" || $many=="" || $during=="" || $many==""){
        echo 0;
}else{
$sql="insert into reserve(place,chDate,chTime,during,many,putid) values('$place','$chDate','$chTime','$during','$many','$id')";
        $rs=mysqli_query($conn,$sql);
        echo $rs;
    }
?>